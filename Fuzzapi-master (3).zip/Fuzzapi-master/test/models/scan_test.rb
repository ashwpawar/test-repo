require 'test_helper'

class ScanTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
